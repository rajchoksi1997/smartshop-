export class product{
    productCode:string;
    productName:string;
    productType : string;
    brand : string;
    ratePerQuantity : Number;
    stockCount : Number;
    addDate : Date;
    aisle : String;
    shelf : String;
    dateOfManf:Date;
    dateOfExp:Date;
    productImg : string;

    constructor() {

    }
}