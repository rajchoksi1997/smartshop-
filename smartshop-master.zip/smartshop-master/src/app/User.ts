export interface User {
    userId: string;
    firstName: string;
    lastName: string;
    gender:boolean;
    password:string;
    contactNumber:number;
    age:number;
    secQuestion: string;
    secAnswer:string;
}