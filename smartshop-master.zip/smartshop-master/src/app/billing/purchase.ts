export class purchase {
    
    userId : string;
    productCode : string;
    quantity : number;
    amount : number;
    productName: string;
    
    constructor() {
        this.userId = "";
    }
}