export class UserFeedback
 {
    
    userId :string ;
    ratingQues1 : string;
    ratingQues2 : string;
    ratingQues3 : string;
    ratingQues4 : string;
    ratingQues5 : string;

    constructor() {
        
    }
}